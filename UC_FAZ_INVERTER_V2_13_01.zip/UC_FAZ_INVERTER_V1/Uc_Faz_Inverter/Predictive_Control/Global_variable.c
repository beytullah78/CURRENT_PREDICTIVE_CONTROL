/*
 * Global_variable.c
 *
 *  Created on: 19 Eyl 2020
 *      Author: ASUS
 */


#include "Global_variable.h"

GL_t GL={0};        // GL_t struct i�indeki b�t�n de�i�kenleri 0 yapt�k.
