/*
 * kontrol_algoritma.c
 *
 *  Created on: 20 Ara 2020
 *      Author: ASUS
 */



/*
 * Yazan         :  BEYTULLAH ���EKC�
 * Fonksiyon ad� :  algoritma_kontrol
 * Dondurulen    :  void
 * Saat-Tarih    :  20:57:05 - 26 Eyl 2020
 *
 * Versiyon      :
 * Aciklama      :
 *
 */
#include "akim_kontrol.h"

void kontrol_algoritma(void)
{
    GL.algoritma_t.FAZ_1_Ref_s16 = -2;
    GL.algoritma_t.FAZ_2_Ref_s16 = 2;
    GL.algoritma_t.FAZ_3_Ref_s16 = -2;

UINT8 states[24] = {0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1};

UINT8 dongu_u8;

    for( dongu_u8=0 ; dongu_u8< VEKTOR_SAYICI ; dongu_u8++)
    {

        GL.algoritma_t.dizi_u8= ( dongu_u8 * VEKTOR_CARP );

        GL.algoritma_t.Sa1_u8 = states[  GL.algoritma_t.dizi_u8 ];

        GL.algoritma_t.Sb1_u8 = states[( GL.algoritma_t.dizi_u8 + 1 )];

        GL.algoritma_t.Sc1_u8 = states[( GL.algoritma_t.dizi_u8 + 2 )];

        GL.algoritma_t.VaN_u16 = ( GL.algoritma_t.Sa1_u8 * GL.algoritma_t.Vdc_u16 );

        GL.algoritma_t.VbN_u16 = ( GL.algoritma_t.Sb1_u8 * GL.algoritma_t.Vdc_u16 );

        GL.algoritma_t.VcN_u16 = ( GL.algoritma_t.Sc1_u8 * GL.algoritma_t.Vdc_u16 );

        GL.algoritma_t.Vcm = ( GL.algoritma_t.VaN_u16 + GL.algoritma_t.VbN_u16 + GL.algoritma_t.VcN_u16 ) / 3 ;

        GL.algoritma_t.Va0 = ( GL.algoritma_t.VaN_u16 - GL.algoritma_t.Vcm );

        GL.algoritma_t.Vb0 = ( GL.algoritma_t.VbN_u16 - GL.algoritma_t.Vcm );

        GL.algoritma_t.Vc0 = ( GL.algoritma_t.VcN_u16 - GL.algoritma_t.Vcm );

// hesaplamalar� elle yapt�k

        GL.algoritma_t.I0ak =  ( GL.algoritma_t.Ts * GL.algoritma_t.Va0 ) + ( GL.adc_okuma_t.FAZ_1_u16 * GL.algoritma_t.L ) ;
        GL.algoritma_t.I0bk =  ( GL.algoritma_t.Ts * GL.algoritma_t.Vb0 ) + ( GL.adc_okuma_t.FAZ_2_u16 * GL.algoritma_t.L ) ;
        GL.algoritma_t.I0ck =  ( GL.algoritma_t.Ts * GL.algoritma_t.Vc0 ) + ( GL.adc_okuma_t.FAZ_3_u16 * GL.algoritma_t.L ) ;

        /*
       GL.algoritma_t.I0ak = ( ( ( GL.algoritma_t.Ts / GL.algoritma_t.L ) * GL.algoritma_t.Va0 ) + ( GL.adc_okuma_t.FAZ_1_u16 * ( 1 - ( GL.algoritma_t.R_u8 * GL.algoritma_t.Ts) / GL.algoritma_t.L ) ) );
       GL.algoritma_t.I0bk = ( ( ( GL.algoritma_t.Ts / GL.algoritma_t.L ) * GL.algoritma_t.Vb0 ) + ( GL.adc_okuma_t.FAZ_2_u16 * ( 1 - ( GL.algoritma_t.R_u8 * GL.algoritma_t.Ts) / GL.algoritma_t.L ) ) );
       GL.algoritma_t.I0ck = ( ( ( GL.algoritma_t.Ts / GL.algoritma_t.L ) * GL.algoritma_t.Vc0 ) + ( GL.adc_okuma_t.FAZ_3_u16 * ( 1 - ( GL.algoritma_t.R_u8 * GL.algoritma_t.Ts) / GL.algoritma_t.L ) ) );
*/
        // Cost function

        GL.algoritma_t.g =  fabsf( GL.algoritma_t.FAZ_1_Ref_s16 - GL.algoritma_t.I0ak ) + fabsf( GL.algoritma_t.FAZ_2_Ref_s16 - GL.algoritma_t.I0bk ) + fabsf( GL.algoritma_t.FAZ_3_Ref_s16 - GL.algoritma_t.I0ck );

        if ( GL.algoritma_t.g  < GL.algoritma_t.g_opt )
        {
            GL.algoritma_t.g_opt = GL.algoritma_t.g;

            GL.algoritma_t.x_opt_u8 = GL.algoritma_t.dizi_u8;
        }
    }

    GL.algoritma_t.Sa_u8=states[GL.algoritma_t.x_opt_u8];      // for d�ng�s�n�n d���nda GL.algoritma_t.dizi  de�eri de�i�iyor mu kontrol et ?
    GL.algoritma_t.Sb_u8=states[GL.algoritma_t.x_opt_u8 + 1];
    GL.algoritma_t.Sc_u8=states[GL.algoritma_t.x_opt_u8 + 2];
}
