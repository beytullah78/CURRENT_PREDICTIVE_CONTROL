/*
 * kontrol_algoritmasi.h
 *
 *  Created on: 20 Ara 2020
 *      Author: ASUS
 */

#ifndef UC_FAZ_INVERTER_PREDICTIVE_CONTROL_KONTROL_ALGORITMA_H_
#define UC_FAZ_INVERTER_PREDICTIVE_CONTROL_KONTROL_ALGORITMA_H_

void kontrol_algoritma(void);

#endif /* UC_FAZ_INVERTER_PREDICTIVE_CONTROL_KONTROL_ALGORITMA_H_ */
