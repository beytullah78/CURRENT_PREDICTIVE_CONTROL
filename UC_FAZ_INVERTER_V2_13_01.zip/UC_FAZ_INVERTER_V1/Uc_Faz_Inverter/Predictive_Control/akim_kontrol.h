/*
 * akim_kontrol.h
 *
 *  Created on: 19 Eyl 2020
 *      Author: ASUS
 */

#ifndef UC_FAZ_INVERTER_PREDICTIVE_CONTROL_AKIM_KONTROL_H_
#define UC_FAZ_INVERTER_PREDICTIVE_CONTROL_AKIM_KONTROL_H_

#define ADC_PORT                       GPIO_PORTE_BASE // AYNI ZAMANDA GATE S�R�C�LER�N ENABLE PORTU

#define FAZ_1_P�N                      GPIO_PIN_1
#define FAZ_2_P�N                      GPIO_PIN_2
#define FAZ_3_P�N                      GPIO_PIN_3

#define FAZ_1_KANAL                    ADC_CTL_CH0
#define FAZ_2_KANAL                    ADC_CTL_CH1
#define FAZ_3_KANAL                    ADC_CTL_CH2

#define VEKTOR_SAYICI                   8
#define VEKTOR_CARP                     3

#define VOLTAGE_OFFSET                2.45
#define Hassasiyet                    0.185

#include "Global_variable.h"
#include "sin_egrisi.h"
#include "kontrol_algoritma.h"

#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "math.h"

#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/adc.h"
#include "driverlib/fpu.h"

void mcu_frekansi_ayarlama(void);
void gate_s�r�c�ler_pinler_init(void);
void adc_cevre_birimi_init(void);
void algoritma_init(void);
void gate_s�r�c�ler_enable(void);
void timer_cevre_birimi_init(void);


void adc_okuma(void);
void gate_s�r�c�ler_pin_reset(void);
void gate_s�r�c�ler_vekt�rler_pinler(void);






#endif /* UC_FAZ_INVERTER_PREDICTIVE_CONTROL_AKIM_KONTROL_H_ */
