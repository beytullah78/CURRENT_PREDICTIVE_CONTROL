/*
 * �nverter_main.h
 *
 *  Created on: 19 Eyl 2020
 *      Author: ASUS
 */

#ifndef UC_FAZ_INVERTER_INVERTER_MAIN_H_
#define UC_FAZ_INVERTER_INVERTER_MAIN_H_

#include "pin_tanimlamalari.h"

INT inverter_main(void);


#endif /* UC_FAZ_INVERTER_INVERTER_MAIN_H_ */
