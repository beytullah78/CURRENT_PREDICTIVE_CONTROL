
#include "inverter_main.h"
#include "inc/tm4c123gh6pm.h"
#include "main.h"


void main()
 {
   inverter_main();
}
