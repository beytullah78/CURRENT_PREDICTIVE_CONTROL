/*
 * main.h
 *
 *  Created on: 24 Eki 2020
 *      Author: ASUS
 */

#ifndef MAIN_H_
#define MAIN_H_


void main();


#endif /* MAIN_H_ */
